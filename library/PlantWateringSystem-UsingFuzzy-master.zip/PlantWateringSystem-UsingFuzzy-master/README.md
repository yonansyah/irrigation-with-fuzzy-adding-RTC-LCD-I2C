# PlantWateringSystem-UsingFuzzy


Plant Watering System using fuzzy logic


HARDWARE




ESPectro32 (https://shop.makestro.com/product/espectro32/)

Motor Backpack for ESPectro32 

Soil Moisture Sensor

Soil Temperature Sensor DS18B20

12V DC Water Pump






Libraries used in this code

https://github.com/adafruit/Adafruit_Motor_Shield_V2_Library

https://github.com/PaulStoffregen/OneWire

https://github.com/milesburton/Arduino-Temperature-Control-Library

https://github.com/Apollon77/I2CSoilMoistureSensor

https://github.com/bblanchon/ArduinoJson

https://github.com/knolleary/pubsubclient

https://github.com/zerokol/eFLL

