# esp32smarthomev2.0
esp32 smarthome board

if u have a question about this project ,email me at dafanur18@gmail.com



