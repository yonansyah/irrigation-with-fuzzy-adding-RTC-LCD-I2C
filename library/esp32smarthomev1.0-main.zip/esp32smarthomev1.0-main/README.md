# esp32smarthomev1.0
esp32 smart home v1.0 
if u have a question about this project ,email me at dafanur18@gmail.com

https://www.bukalapak.com/p/elektronik/elektronik-lainnya/4346tge-jual-smart-home-berbasis-esp32?from=product_owner&product_owner=normal_seller

![smarthomev1](https://user-images.githubusercontent.com/75739124/103281658-fb84ac00-4a05-11eb-8887-a884c2d49afb.jpeg)
